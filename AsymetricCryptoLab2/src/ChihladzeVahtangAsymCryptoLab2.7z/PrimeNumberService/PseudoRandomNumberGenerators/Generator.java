package PrimeNumberService.PseudoRandomNumberGenerators;

public interface Generator {

    public byte[] generateBytes(int howManyBytesToGenerate);

}
