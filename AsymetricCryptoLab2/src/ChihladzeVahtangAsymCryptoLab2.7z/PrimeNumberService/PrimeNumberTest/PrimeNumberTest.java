package PrimeNumberService.PrimeNumberTest;

import java.math.BigInteger;

public interface PrimeNumberTest {

    public boolean isPrime(BigInteger number);
    public boolean isPrime(byte[] number);
}
